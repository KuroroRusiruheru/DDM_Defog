clear



  PIC=imread("");
  PIC = double(PIC)./255;
  output0 = func_DCP_noSkyDetect(PIC);
    %imshow(output0);title( 'DCP');
   

