function s = sigmoid(x)
    s = exp(x)./(1+exp(x));
end