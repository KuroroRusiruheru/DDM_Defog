# SuperPixelFusion
 Demo of the ICASSP 2023 paper "Multispectral Image Fusion Based on Super Pixel Segmentation"
